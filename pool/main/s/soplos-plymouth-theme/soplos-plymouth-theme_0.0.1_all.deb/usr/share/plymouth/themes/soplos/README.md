# Soplos Plymouth Theme

**Author:** Sergi Perich  
**Version:** 2.0 (Clean & Minimalist)

A modern, minimalist Plymouth theme for Soplos Linux. Features a smooth centered logo animation with a breathing glow effect, set against a pure black background. Designed for elegance and simplicity.

## Features
- **Minimalist Design:** No distracting elements, just the core brand identity.
- **Smooth Animation:** Custom synchronized frame animation.
- **Smart Layout:** System messages (updates, fsck) are positioned to avoid overlapping the central logo.
- **English Support:** All system messages are standardized in English.

## Installation

To install this theme on your system:

1.  **Copy the theme folder** to the system directory:
    ```bash
    sudo cp -r /path/to/plymouth-soplos /usr/share/plymouth/themes/soplos
    ```

2.  **Set as default and rebuild initramfs:**
    ```bash
    sudo plymouth-set-default-theme -R soplos
    ```

3.  **Verify:**
    Reboot your system to see the changes.

## License
Created by Sergi Perich for Soplos Linux.
