#!/usr/bin/env python3

from setuptools import setup, find_packages

setup(
    name='soplos-layout-switcher',
    version='1.0.0',
    description='GNOME Shell layout presets for Soplos Linux',
    long_description=open('README.md', encoding='utf-8').read() if __import__('pathlib').Path('README.md').exists() else '',
    long_description_content_type='text/markdown',
    license='GPL-3.0-or-later',
    url='https://github.com/SoplosLinux/soplos-layout-switcher',
    keywords=["gnome", "soplos", "layout"],
    author='Soplos Project',
    author_email='info@soploslinux.com',
    python_requires='>=3.8',
    install_requires=['click'],
    packages=find_packages(exclude=['tests', 'debian']) + ['layoutswitcherlib'],
    package_dir={'layoutswitcherlib': 'bin/layoutswitcherlib'},
    include_package_data=True,
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: X11 Applications :: GTK',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3',
    ],
    entry_points={
        'gui_scripts': [
            'soplos-layout-switcher = main:main',
        ]
    },
    data_files=[
        ('share/icons/hicolor/64x64/apps', [
            'assets/icons/64x64/org.soplos.layoutswitcher.png',
        ]),
        ('share/soplos-layout-switcher/pictures', [
            'data/pictures/gnomepreview.svg',
            'data/pictures/soplospreview.svg',
            'data/pictures/dockpreview.svg',
            'data/pictures/tilingpreview.svg',
        ]),
        ('share/soplos-layout-switcher/schemas', [
            'data/schemas/traditional_layout',
        ]),
        ('bin/', [
            'bin/soplos-layout-switcher-cli',
        ]),
        ('share/applications', [
            'data/desktop/soplos-layout-switcher.desktop',
        ]),
    ],
    project_urls={
        'Source': 'https://github.com/SoplosLinux/soplos-layout-switcher',
        'Tracker': 'https://github.com/SoplosLinux/soplos-layout-switcher/issues',
        'Soplos': 'https://soplos.org'
    }
)
