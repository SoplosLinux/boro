#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Soplos Layout Switcher 1.0.0

Main application entry point.
"""

import sys
import os
import warnings
from pathlib import Path

# Add the project root and the bin/ directory (where layoutswitcherlib lives) to PYTHONPATH
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / 'bin'))

# Suppress accessibility warnings for a cleaner output
warnings.filterwarnings('ignore', '.*Couldn\'t connect to accessibility bus.*', Warning)
warnings.filterwarnings('ignore', '.*Failed to connect to socket.*', Warning)

# Disable accessibility bridge unless explicitly enabled
if not os.environ.get('ENABLE_ACCESSIBILITY'):
    os.environ['NO_AT_BRIDGE'] = '1'
    os.environ['AT_SPI_BUS'] = '0'

def cleanup_pycache():
    """Recursively remove __pycache__ directories."""
    import shutil
    try:
        for p in PROJECT_ROOT.rglob('__pycache__'):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
    except Exception as e:
        print(f"Warning: Failed to cleanup pycache: {e}")

def main():
    """Main entry point for Soplos Layout Switcher."""
    exit_code = 0
    try:
        from core.application import run_application
        exit_code = run_application()

    except ImportError as e:
        print(f"Import error: {e}")
        print("Ensure all dependencies are installed:")
        print("  sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0 python3-click")
        import traceback
        traceback.print_exc()
        exit_code = 1

    except Exception as e:
        print(f"Application error: {e}")
        import traceback
        traceback.print_exc()
        exit_code = 1

    finally:
        cleanup_pycache()

    return exit_code

if __name__ == '__main__':
    sys.exit(main())
