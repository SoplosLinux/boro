# Soplos Layout Switcher

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Soplos Layout Switcher is a graphical utility for Soplos Boro (GNOME) that switches
the desktop between predefined GNOME Shell layouts by enabling/disabling the
required shell extensions and applying the matching gsettings.

Ported from [gnome-layout-switcher](https://gitlab.manjaro.org/Chrysostomus/gnome-layout-switcher)
(Manjaro Linux) and adapted for Debian/apt-based systems.

## Screenshots

Layout tab:

![Layout](assets/screenshots/screenshot1.png)

Settings tab:

![Settings](assets/screenshots/screenshot2.png)

## Layouts

- **Soplos** — the default Boro appearance: Dash to Panel + ArcMenu (Soplos
  branding), Desktop Icons NG, Quick Settings Tweaks.
- **Dock** — a macOS-style dock (Dash to Dock, bottom position).
- **Tiling** — Forge (tiling window manager) + Dash to Dock (left position) +
  Open Bar (top bar theming) + AppIndicator + Blur my Shell + Workspace
  Indicator. Forge and Open Bar have no Debian package and no working build
  on extensions.gnome.org for current GNOME Shell versions yet, so they ship
  bundled with this app (`data/extensions/`) instead.
- **GNOME** — stock GNOME Shell, no extra extensions.

A handful of extensions (Coverflow Alt-Tab, Clipboard Indicator, Desktop
Cube, Removable Drive Menu, User Themes) are treated as the user's own
desktop taste and are never touched by any preset.

The Settings tab also gives quick access to GNOME Tweaks, Extension Manager,
GDM Settings and Firefox theming (Add Water, installed automatically via
Flatpak the first time it's used), and toggles for the system tray and
desktop icons extensions.

## Usage

Launch it from the applications menu, or run:

```
soplos-layout-switcher
```

For scripting (e.g. installers) without opening the GUI:

```
soplos-layout-switcher-cli apply-soplos
soplos-layout-switcher-cli apply-dock
soplos-layout-switcher-cli apply-gnome
soplos-layout-switcher-cli apply-tiling
soplos-layout-switcher-cli reload-gnome-shell
```

## Requirements

- Python 3.8+
- GTK 3 / PyGObject (`python3-gi`, `gir1.2-gtk-3.0`)
- `click`
- GNOME Shell (this app only runs under GNOME)

## License

GPL-3.0-or-later. See [LICENSE](LICENSE).
