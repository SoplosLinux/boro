"""
Main application class for Soplos Layout Switcher.
Handles application lifecycle, initialization, and coordination between modules.
"""

import sys
import os
import signal
from pathlib import Path

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Gio

from .environment import get_environment_detector
from .i18n_manager import get_i18n_manager, initialize_i18n, _
from utils.logger import log_info, log_error, log_warning
from config.constants import APP_ID, APP_NAME, APP_VERSION


class SoplosLayoutSwitcherApplication(Gtk.Application):
    """
    Main application class for Soplos Layout Switcher.
    Manages the application lifecycle and coordinates between all components.
    """

    def __init__(self):
        """Initialize the application."""
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE
        )

        # Application state
        self.main_window = None
        self.environment_detector = None
        self.i18n_manager = None

        # Application paths
        self.app_path = Path(__file__).parent.parent
        self.assets_path = self.app_path / 'assets'
        self.locale_path = self.app_path / 'locale'

        # Connect signals
        self.connect('startup', self.on_startup)
        self.connect('activate', self.on_activate)
        self.connect('command-line', self.on_command_line)
        self.connect('shutdown', self.on_shutdown)

        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def on_shutdown(self, app):
        """Called when the application shuts down."""
        log_info(_("Shutting down Soplos Layout Switcher..."))

    def on_startup(self, app):
        """Called when the application starts up."""
        log_info(_("Starting {name} v{ver}...").format(name=APP_NAME, ver=APP_VERSION))

        self._initialize_environment()
        self._initialize_internationalization()
        self._setup_application_properties()

        log_info(_("Application initialization completed"))

    def on_activate(self, app):
        """Called when the application is activated."""
        if self.main_window is None:
            self._create_main_window()

        if self.main_window:
            self.main_window.present()

    def on_command_line(self, app, command_line):
        """Handle command line arguments."""
        self.activate()
        return 0

    def _initialize_environment(self):
        """Initialize environment detection."""
        try:
            self.environment_detector = get_environment_detector()
            self.environment_detector.detect_all()
            self.environment_detector.configure_environment_variables()
        except Exception as e:
            log_error(_("Error initializing environment detection: {err}").format(err=e))

    def _initialize_internationalization(self):
        """Initialize the internationalization system."""
        try:
            current_lang = initialize_i18n(str(self.locale_path))
            self.i18n_manager = get_i18n_manager()
            log_info(_("Language initialized: {lang}").format(lang=current_lang))

            import gettext
            gettext.bindtextdomain('soplos-layout-switcher', str(self.locale_path))
            gettext.textdomain('soplos-layout-switcher')

        except Exception as e:
            log_error(_("Error initializing internationalization: {err}").format(err=e))

    def _setup_application_properties(self):
        """Setup application-wide properties."""
        GLib.set_prgname(APP_ID)
        GLib.set_application_name(_(APP_NAME))

        if hasattr(Gdk, 'set_program_class'):
            Gdk.set_program_class(APP_ID)

        icon_path = self.assets_path / 'icons' / 'org.soplos.layoutswitcher.png'
        if icon_path.exists():
            try:
                Gtk.Window.set_default_icon_from_file(str(icon_path))
            except Exception as e:
                log_warning(_("Error setting application icon: {err}").format(err=e))

    def _create_main_window(self):
        """Create the main application window."""
        try:
            from ui.main_window import MainWindow

            self.main_window = MainWindow(
                application=self,
                environment_detector=self.environment_detector,
                i18n_manager=self.i18n_manager
            )

            self.main_window.connect('destroy', self._on_window_destroy)

        except Exception as e:
            log_error(_("Error creating main window: {err}").format(err=e))
            import traceback
            traceback.print_exc()
            self.quit()

    def _on_window_destroy(self, window):
        """Handle main window destruction."""
        self.main_window = None
        self.quit()

    def _handle_signal(self, signum, frame):
        """Handle system signals for graceful shutdown."""
        log_info(_("Received signal {num}, shutting down...").format(num=signum))
        GLib.idle_add(self.quit)


def run_application(argv: list = None) -> int:
    """Run the application."""
    if argv is None:
        argv = sys.argv

    app = SoplosLayoutSwitcherApplication()

    try:
        return app.run(argv)
    except KeyboardInterrupt:
        return 0
    except Exception as e:
        log_error(_("Application error: {err}").format(err=e))
        return 1
