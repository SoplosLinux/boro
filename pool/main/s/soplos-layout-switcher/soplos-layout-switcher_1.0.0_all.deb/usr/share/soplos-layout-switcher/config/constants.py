"""
Configuration constants for Soplos Layout Switcher.
"""

APP_ID = "org.soplos.layoutswitcher"
APP_NAME = "Soplos Layout Switcher"
APP_VERSION = "1.0.0"

# Window dimensions
DEFAULT_WINDOW_WIDTH = 700
DEFAULT_WINDOW_HEIGHT = 600
MIN_WINDOW_WIDTH = 650
MIN_WINDOW_HEIGHT = 550
