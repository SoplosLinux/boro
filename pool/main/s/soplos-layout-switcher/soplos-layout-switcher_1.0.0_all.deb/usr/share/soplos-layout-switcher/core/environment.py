"""
Environment detection module for Soplos Layout Switcher.
Handles display protocol identification for the footer status bar.
This app is GNOME-only (OnlyShowIn=GNOME), so no multi-DE detection is needed.
"""

import os
import subprocess
from typing import Dict
from enum import Enum


class DisplayProtocol(Enum):
    """Display server protocols."""
    X11 = "x11"
    WAYLAND = "wayland"
    UNKNOWN = "unknown"


class EnvironmentDetector:
    """
    Detects the current display protocol and GNOME Shell version.
    """

    def __init__(self):
        self._display_protocol = None
        self._environment_info = {}

    def detect_all(self) -> Dict[str, str]:
        """
        Performs environment detection.

        Returns:
            Dictionary with detected environment information
        """
        self._detect_display_protocol()
        self._detect_additional_info()

        return {
            'desktop_environment': 'gnome',
            'display_protocol': self._display_protocol.value,
            'environment_info': self._environment_info
        }

    def _detect_display_protocol(self) -> DisplayProtocol:
        """Detects the display server protocol (X11 or Wayland)."""
        session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()

        if session_type == 'wayland':
            self._display_protocol = DisplayProtocol.WAYLAND
        elif session_type == 'x11' or os.environ.get('DISPLAY'):
            self._display_protocol = DisplayProtocol.X11
        else:
            self._display_protocol = DisplayProtocol.UNKNOWN

        return self._display_protocol

    def _detect_additional_info(self):
        """Collects additional environment information."""
        self._environment_info = {
            'gnome_shell_version': self._detect_gnome_shell_version(),
        }

    def _detect_gnome_shell_version(self) -> str:
        """Detects the installed GNOME Shell version."""
        try:
            result = subprocess.run(
                ['gnome-shell', '--version'], capture_output=True, text=True, timeout=3, check=False)
            if result.returncode == 0:
                return result.stdout.strip()
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return 'unknown'

    @property
    def display_protocol(self) -> DisplayProtocol:
        """Current display protocol."""
        if self._display_protocol is None:
            self._detect_display_protocol()
        return self._display_protocol

    @property
    def is_wayland(self) -> bool:
        """True if running on Wayland."""
        return self.display_protocol == DisplayProtocol.WAYLAND

    def configure_environment_variables(self):
        """Configures environment variables for optimal GTK integration."""
        if self.is_wayland:
            os.environ['GTK_USE_PORTAL'] = '1'
            os.environ['GDK_BACKEND'] = 'wayland'

        # Disable accessibility bus if not needed (reduces startup time)
        if not os.environ.get('ENABLE_ACCESSIBILITY'):
            os.environ['NO_AT_BRIDGE'] = '1'
            os.environ['AT_SPI_BUS'] = '0'


# Global instance for easy access
_environment_detector = None

def get_environment_detector() -> EnvironmentDetector:
    """
    Returns the global environment detector instance.
    Creates it if it doesn't exist.
    """
    global _environment_detector
    if _environment_detector is None:
        _environment_detector = EnvironmentDetector()
    return _environment_detector

def detect_environment() -> Dict[str, str]:
    """
    Convenience function to detect all environment information.

    Returns:
        Dictionary with complete environment detection results
    """
    detector = get_environment_detector()
    return detector.detect_all()
