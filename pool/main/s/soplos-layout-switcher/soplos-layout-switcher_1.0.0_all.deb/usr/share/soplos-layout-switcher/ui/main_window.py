"""
Main Application Window.
Strict Soplos style: Header + Content (LayoutBox) + Footer.
The actual layout-switching engine lives untouched in
bin/layoutswitcherlib/layoutsbox.py (ported from Manjaro's gnome-layout-switcher);
this window only wraps it with the standard Soplos chrome.
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
from pathlib import Path

from core.i18n_manager import _
from config.constants import APP_NAME, APP_VERSION, DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT
from layoutswitcherlib.layoutsbox import LayoutBox


class MainWindow(Gtk.ApplicationWindow):
    """Main application window for Soplos Layout Switcher."""

    def __init__(self, application, environment_detector, i18n_manager):
        """Initialize the main window."""
        super().__init__(application=application)

        self.application = application
        self.environment_detector = environment_detector
        self.i18n_manager = i18n_manager

        # Window properties
        self.set_title(_(APP_NAME))
        self.set_default_size(DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT)
        self.set_position(Gtk.WindowPosition.CENTER)

        self.get_style_context().add_class('soplos-window')
        try:
            self.get_style_context().add_class('soplos-welcome-window')
            self.set_name('main-window')
        except Exception:
            pass

        self._create_header_bar()
        self._setup_ui()
        self.show_all()

        self._update_system_info()

        self.connect('delete-event', self._on_delete_event)
        self.connect('key-press-event', self._on_key_press)

    def _create_header_bar(self):
        """Create a clean HeaderBar, matching the rest of the Soplos apps."""
        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.set_title(_(APP_NAME))
        header.set_decoration_layout("menu:minimize,maximize,close")
        header.get_style_context().add_class('titlebar')
        self.set_titlebar(header)
        self.header = header

    def _setup_ui(self):
        """Initializes the main UI: LayoutBox content + footer status bar."""
        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(main_vbox)

        # --- CONTENT (the ported layout switcher engine) ---
        self.layout_box = LayoutBox(self)
        main_vbox.pack_start(self.layout_box, True, True, 0)

        # --- FOOTER (Status Bar) ---
        self._create_status_bar(main_vbox)

    def _create_status_bar(self, main_vbox):
        """Create footer status bar, same layout as the rest of the Soplos apps."""
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        status_box.set_margin_start(15)
        status_box.set_margin_end(15)
        status_box.set_margin_top(8)
        status_box.set_margin_bottom(8)

        self.system_label = Gtk.Label()
        self.system_label.set_halign(Gtk.Align.START)
        self.system_label.get_style_context().add_class('dim-label')
        status_box.pack_start(self.system_label, False, False, 0)

        version_label = Gtk.Label(label=f"v{APP_VERSION}")
        version_label.set_halign(Gtk.Align.END)
        version_label.get_style_context().add_class('dim-label')
        status_box.pack_end(version_label, False, False, 0)

        main_vbox.pack_end(status_box, False, False, 0)

    def _update_system_info(self):
        """Detect and display system info."""
        env_info = self.environment_detector.detect_all()
        protocol = env_info['display_protocol']
        protocol_name = self._translate_protocol_name(protocol)
        self.system_label.set_text(f"{_('GNOME Shell')}  ·  {protocol_name}")

    def _translate_protocol_name(self, protocol):
        """Translate display protocol name."""
        protocol_map = {
            'x11': _("X11"),
            'wayland': _("Wayland"),
            'unknown': _("Unknown")
        }
        return protocol_map.get(protocol.lower(), _("Unknown"))

    # ==================== Event Handlers ====================

    def _on_delete_event(self, widget, event):
        """Handle window close event."""
        return False  # Allow window to close

    def _on_key_press(self, widget, event):
        """Handle key press events."""
        keyval = event.keyval
        state = event.state

        if state & Gdk.ModifierType.CONTROL_MASK:
            if keyval == Gdk.KEY_q:
                self.close()
                return True

        if keyval == Gdk.KEY_F1:
            self._show_about()
            return True

        return False

    def _show_about(self):
        dialog = Gtk.AboutDialog()
        dialog.set_transient_for(self)
        dialog.set_modal(True)
        dialog.set_program_name(_(APP_NAME))
        dialog.set_version(APP_VERSION)
        dialog.set_comments(_("Switches the GNOME Shell desktop between predefined layouts."))
        dialog.set_website("https://soplos.org")
        dialog.set_website_label("soplos.org")
        dialog.set_authors(["Sergi Perich <info@soploslinux.com>"])
        dialog.set_license_type(Gtk.License.GPL_3_0)
        icon_path = Path(__file__).parent.parent / 'assets' / 'icons' / '64x64' / 'org.soplos.layoutswitcher.png'
        if icon_path.exists():
            dialog.set_logo(GdkPixbuf.Pixbuf.new_from_file_at_scale(str(icon_path), 48, 48, True))
        _about_css = Gtk.CssProvider()
        _about_css.load_from_data(b"""
            dialog, messagedialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            dialog .background, messagedialog .background {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            dialog > box, messagedialog > box {
                background-color: #2b2b2b;
            }
            dialog label, messagedialog label {
                color: #ffffff;
            }
            dialog button, messagedialog button {
                background-image: none;
                background-color: #333333;
                color: #ffffff;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 6px 14px;
                min-height: 0;
                box-shadow: none;
            }
            dialog button:hover, messagedialog button:hover {
                background-color: #444444;
                border-color: #ff8800;
            }
            dialog stackswitcher button {
                border-radius: 100px;
                background-color: #2b2b2b;
                background-image: none;
                border: 1px solid #3c3c3c;
                font-weight: normal;
                padding: 4px 16px;
                min-height: 0;
                box-shadow: none;
                color: #ffffff;
            }
            dialog stackswitcher button:hover {
                background-color: #444444;
                border-color: #ff8800;
            }
            dialog stackswitcher button:checked {
                background-color: #444444;
                color: #ffffff;
            }
        """)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), _about_css,
            Gtk.STYLE_PROVIDER_PRIORITY_USER
        )
        dialog.run()
        dialog.destroy()
