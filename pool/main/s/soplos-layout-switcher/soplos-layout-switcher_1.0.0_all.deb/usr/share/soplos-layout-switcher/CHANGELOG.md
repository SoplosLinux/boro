# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/lang/en/).

## [1.0.0] - 2026-07-19

### Added
- Initial Soplos port of Manjaro's gnome-layout-switcher, adapted to the
  standard Soplos application skeleton (`main.py`, `core/`, `config/`, `ui/`,
  `utils/`), with header bar, footer status bar and About dialog matching
  the rest of the Soplos apps.
- Four layout presets: Soplos (dash-to-panel, the default Boro appearance),
  Dock (dash-to-dock), Tiling, and GNOME.
- Settings tab: GNOME Tweaks, GNOME Extensions manager, GDM Settings,
  Firefox theming (Add Water), system tray toggle and desktop icons toggle.
- Full internationalization (gettext) in 8 languages: Spanish, English,
  French, German, Portuguese, Italian, Romanian and Russian.
- CLI-only entry point (`soplos-layout-switcher-cli`) for scripting layout
  changes without opening the GUI.
- Extension-to-package mapping switched from Manjaro's pacman/pamac to
  apt/dpkg for Debian-based Soplos systems.
- Tiling preset rebuilt against a verified, real Soplos Boro tiling setup
  (Forge, Dash to Dock, Open Bar, AppIndicator, Blur my Shell, Workspace
  Indicator), with Forge and Open Bar bundled as pre-built extensions
  (`data/extensions/`) since neither has a Debian package and their
  extensions.gnome.org builds don't yet declare support for this GNOME
  Shell version.
- Every layout's required/conflicting extension list cross-checked against
  `gnome-extensions list --enabled` and `dconf dump` on a real Boro install,
  instead of inherited assumptions from the original Manjaro source.

### Fixed
- `dpkg -s` package check silently always reported "installed" due to a
  bash-only `&>` redirection running under `dash`; switched to argument-list
  `subprocess.run` so missing packages are actually detected and installed.
- Desktop icons extension uuid corrected from Manjaro's
  `gtk4-ding@smedius.gitlab.com` to Boro's real `ding@rastersoft.com`.
- System tray / desktop icons toggles in Settings never reflected the real
  state, because `gnome-extensions info` output is localized and the code
  matched the English word "ENABLED"; switched to the locale-independent
  `gnome-extensions list --enabled`.
- `gsettings set` failed with "no existe el esquema" for extensions
  installed only in the user's local extensions folder (Open Bar, Blur my
  Shell), since their schema isn't registered system-wide; switched to
  `dconf write`, which doesn't require schema registration.
- Switching away from a layout could leave extensions from the previous one
  still enabled (e.g. Dash to Panel and Dash to Dock active at the same
  time), because each preset's conflicting-extensions list didn't know
  about extensions introduced by other presets later. All four lists now
  cross-reference each other.
- Extension Manager button now tries the native Debian package binary first
  and falls back to the Flatpak (`com.mattjakeman.ExtensionManager`) only if
  that's not installed.
- Accent Colors button called a Manjaro-only helper script
  (`accent-color-change`) with no Soplos equivalent; now opens GNOME
  Settings directly (accent color is a native Settings feature on current
  GNOME).
- GDM Settings and Firefox theming (Add Water) buttons now launch their
  Flatpak equivalents (`io.github.realmazharhussain.GdmSettings`,
  `dev.qwery.AddWater`) since neither has a Debian package; Add Water is
  installed automatically (user-level, no root) the first time it's missing.
- Added a short pause between each extension enable/disable call across all
  four layouts, reducing (though not eliminating — the underlying bugs are
  in the third-party extensions' own disable() handlers) collisions
  observed when several extensions change state back to back.
