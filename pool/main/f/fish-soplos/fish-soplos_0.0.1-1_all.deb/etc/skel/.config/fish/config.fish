if status is-interactive
    set -g fish_greeting ""
    alias neofetch="neofetch --ascii /usr/local/share/logo.txt | sed 's/.*/\x1b[93m&\x1b[0m/'"
    alias ls='ls --color=auto'
end
